import express from 'express';
import pool from '../db/connection.js';
import { getCorrection, getScore, getTone } from '../controllers/correctionsController.js';
const router = express.Router();

// Submit user answer and get correction
router.post('/', async (req, res) => {
    const { userId, scenarioId, userAnswer } = req.body;
    try {
        const correction = await getCorrection(userAnswer);
        const score = await getScore(userAnswer);
        const tone = await getTone(userAnswer);

        const result = await pool.query(
            'INSERT INTO user_answers (user_id, scenario_id, user_answer, corrected_answer, readability_score, tones) VALUES ($1, $2, $3, $4, $5, $6) RETURNING *',
            [userId, scenarioId, userAnswer, correction, score, tone]
        );

        res.status(201).json(result.rows[0]);
    } catch (error) {
        res.status(500).send(error.message);
    }
});

export default router;
